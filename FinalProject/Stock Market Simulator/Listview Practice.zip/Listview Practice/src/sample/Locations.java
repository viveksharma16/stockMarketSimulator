package sample;

public class Locations {
    int x,y;
    public Locations(int xx, int yy){
        x = xx;
        y = yy;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}